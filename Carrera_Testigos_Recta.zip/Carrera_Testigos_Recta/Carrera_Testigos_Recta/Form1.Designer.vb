﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ButtonStart = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.JocToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NouJocToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SurtirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinestraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MinimitzaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ImageCorredores = New System.Windows.Forms.ImageList(Me.components)
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.ButtonVerd = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ButtonRosa = New System.Windows.Forms.Button()
        Me.ButtonGroc = New System.Windows.Forms.Button()
        Me.ButtonBlau = New System.Windows.Forms.Button()
        Me.LabelMet1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.LabelSeconds = New System.Windows.Forms.Label()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.LabelMilliseconds = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelMet2 = New System.Windows.Forms.Label()
        Me.LabelMet3 = New System.Windows.Forms.Label()
        Me.LabelMet4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonStart
        '
        Me.ButtonStart.BackColor = System.Drawing.Color.YellowGreen
        Me.ButtonStart.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonStart.Location = New System.Drawing.Point(561, 55)
        Me.ButtonStart.Name = "ButtonStart"
        Me.ButtonStart.Size = New System.Drawing.Size(317, 36)
        Me.ButtonStart.TabIndex = 0
        Me.ButtonStart.Text = "Comença"
        Me.ButtonStart.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JocToolStripMenuItem, Me.FinestraToolStripMenuItem, Me.AjudaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(898, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'JocToolStripMenuItem
        '
        Me.JocToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NouJocToolStripMenuItem, Me.SurtirToolStripMenuItem})
        Me.JocToolStripMenuItem.Name = "JocToolStripMenuItem"
        Me.JocToolStripMenuItem.Size = New System.Drawing.Size(36, 20)
        Me.JocToolStripMenuItem.Text = "&Joc"
        '
        'NouJocToolStripMenuItem
        '
        Me.NouJocToolStripMenuItem.Name = "NouJocToolStripMenuItem"
        Me.NouJocToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NouJocToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.NouJocToolStripMenuItem.Text = "&Nou Joc..."
        '
        'SurtirToolStripMenuItem
        '
        Me.SurtirToolStripMenuItem.Name = "SurtirToolStripMenuItem"
        Me.SurtirToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.SurtirToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.SurtirToolStripMenuItem.Text = "&Surtir"
        '
        'FinestraToolStripMenuItem
        '
        Me.FinestraToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MinimitzaToolStripMenuItem})
        Me.FinestraToolStripMenuItem.Name = "FinestraToolStripMenuItem"
        Me.FinestraToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.FinestraToolStripMenuItem.Text = "&Finestra"
        '
        'MinimitzaToolStripMenuItem
        '
        Me.MinimitzaToolStripMenuItem.Name = "MinimitzaToolStripMenuItem"
        Me.MinimitzaToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.MinimitzaToolStripMenuItem.Text = "&Minimitza"
        '
        'AjudaToolStripMenuItem
        '
        Me.AjudaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcercaDeToolStripMenuItem})
        Me.AjudaToolStripMenuItem.Name = "AjudaToolStripMenuItem"
        Me.AjudaToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.AjudaToolStripMenuItem.Text = "&Ajuda"
        '
        'AcercaDeToolStripMenuItem
        '
        Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
        Me.AcercaDeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AcercaDeToolStripMenuItem.Text = "A&cerca de..."
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Location = New System.Drawing.Point(60, 135)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Tag = "0"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Location = New System.Drawing.Point(283, 135)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Tag = "1"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Location = New System.Drawing.Point(481, 135)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox3.TabIndex = 4
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Tag = "2"
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Location = New System.Drawing.Point(680, 135)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Tag = "3"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Location = New System.Drawing.Point(60, 191)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox5.TabIndex = 6
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Tag = "4"
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.Location = New System.Drawing.Point(283, 191)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox6.TabIndex = 7
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Tag = "5"
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox7.Location = New System.Drawing.Point(481, 191)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox7.TabIndex = 8
        Me.PictureBox7.TabStop = False
        Me.PictureBox7.Tag = "6"
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox8.Location = New System.Drawing.Point(680, 191)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox8.TabIndex = 9
        Me.PictureBox8.TabStop = False
        Me.PictureBox8.Tag = "7"
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox9.Location = New System.Drawing.Point(60, 248)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox9.TabIndex = 10
        Me.PictureBox9.TabStop = False
        Me.PictureBox9.Tag = "8"
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox10.Location = New System.Drawing.Point(283, 248)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox10.TabIndex = 11
        Me.PictureBox10.TabStop = False
        Me.PictureBox10.Tag = "9"
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox11.Location = New System.Drawing.Point(481, 248)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox11.TabIndex = 12
        Me.PictureBox11.TabStop = False
        Me.PictureBox11.Tag = "10"
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox12.Location = New System.Drawing.Point(680, 248)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox12.TabIndex = 13
        Me.PictureBox12.TabStop = False
        Me.PictureBox12.Tag = "11"
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox13.Location = New System.Drawing.Point(60, 305)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox13.TabIndex = 14
        Me.PictureBox13.TabStop = False
        Me.PictureBox13.Tag = "12"
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox14.Location = New System.Drawing.Point(283, 305)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox14.TabIndex = 15
        Me.PictureBox14.TabStop = False
        Me.PictureBox14.Tag = "13"
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox15.Location = New System.Drawing.Point(481, 305)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox15.TabIndex = 16
        Me.PictureBox15.TabStop = False
        Me.PictureBox15.Tag = "14"
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox16.Location = New System.Drawing.Point(680, 305)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox16.TabIndex = 17
        Me.PictureBox16.TabStop = False
        Me.PictureBox16.Tag = "15"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(381, 353)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(170, 26)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Tauler de resultats"
        '
        'ImageCorredores
        '
        Me.ImageCorredores.ImageStream = CType(resources.GetObject("ImageCorredores.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageCorredores.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageCorredores.Images.SetKeyName(0, "personaVerde.png")
        Me.ImageCorredores.Images.SetKeyName(1, "personaAzul.png")
        Me.ImageCorredores.Images.SetKeyName(2, "personaAmarilla.png")
        Me.ImageCorredores.Images.SetKeyName(3, "personaRosa.png")
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox17.Location = New System.Drawing.Point(848, 135)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(30, 195)
        Me.PictureBox17.TabIndex = 19
        Me.PictureBox17.TabStop = False
        Me.PictureBox17.Tag = "99"
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox18.Location = New System.Drawing.Point(38, 380)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(824, 51)
        Me.PictureBox18.TabIndex = 20
        Me.PictureBox18.TabStop = False
        Me.PictureBox18.Tag = "42"
        '
        'ButtonVerd
        '
        Me.ButtonVerd.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonVerd.Location = New System.Drawing.Point(17, 23)
        Me.ButtonVerd.Name = "ButtonVerd"
        Me.ButtonVerd.Size = New System.Drawing.Size(71, 30)
        Me.ButtonVerd.TabIndex = 22
        Me.ButtonVerd.Text = "Verd"
        Me.ButtonVerd.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.ButtonRosa)
        Me.GroupBox1.Controls.Add(Me.ButtonGroc)
        Me.GroupBox1.Controls.Add(Me.ButtonBlau)
        Me.GroupBox1.Controls.Add(Me.ButtonVerd)
        Me.GroupBox1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(21, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(347, 62)
        Me.GroupBox1.TabIndex = 23
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Eliminar equip:"
        '
        'ButtonRosa
        '
        Me.ButtonRosa.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonRosa.Location = New System.Drawing.Point(260, 23)
        Me.ButtonRosa.Name = "ButtonRosa"
        Me.ButtonRosa.Size = New System.Drawing.Size(71, 30)
        Me.ButtonRosa.TabIndex = 25
        Me.ButtonRosa.Text = "Rosa"
        Me.ButtonRosa.UseVisualStyleBackColor = True
        '
        'ButtonGroc
        '
        Me.ButtonGroc.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGroc.Location = New System.Drawing.Point(179, 23)
        Me.ButtonGroc.Name = "ButtonGroc"
        Me.ButtonGroc.Size = New System.Drawing.Size(71, 30)
        Me.ButtonGroc.TabIndex = 24
        Me.ButtonGroc.Text = "Groc"
        Me.ButtonGroc.UseVisualStyleBackColor = True
        '
        'ButtonBlau
        '
        Me.ButtonBlau.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonBlau.Location = New System.Drawing.Point(98, 23)
        Me.ButtonBlau.Name = "ButtonBlau"
        Me.ButtonBlau.Size = New System.Drawing.Size(71, 30)
        Me.ButtonBlau.TabIndex = 23
        Me.ButtonBlau.Text = "Blau"
        Me.ButtonBlau.UseVisualStyleBackColor = True
        '
        'LabelMet1
        '
        Me.LabelMet1.AutoSize = True
        Me.LabelMet1.BackColor = System.Drawing.Color.Black
        Me.LabelMet1.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMet1.ForeColor = System.Drawing.Color.White
        Me.LabelMet1.Location = New System.Drawing.Point(56, 394)
        Me.LabelMet1.Name = "LabelMet1"
        Me.LabelMet1.Size = New System.Drawing.Size(62, 23)
        Me.LabelMet1.TabIndex = 24
        Me.LabelMet1.Text = "Primer"
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'LabelSeconds
        '
        Me.LabelSeconds.AutoSize = True
        Me.LabelSeconds.BackColor = System.Drawing.Color.Black
        Me.LabelSeconds.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSeconds.ForeColor = System.Drawing.Color.White
        Me.LabelSeconds.Location = New System.Drawing.Point(466, 60)
        Me.LabelSeconds.Name = "LabelSeconds"
        Me.LabelSeconds.Size = New System.Drawing.Size(23, 26)
        Me.LabelSeconds.TabIndex = 25
        Me.LabelSeconds.Text = "0"
        '
        'PictureBox19
        '
        Me.PictureBox19.BackColor = System.Drawing.Color.Black
        Me.PictureBox19.Location = New System.Drawing.Point(458, 55)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(75, 36)
        Me.PictureBox19.TabIndex = 26
        Me.PictureBox19.TabStop = False
        Me.PictureBox19.Tag = "42"
        '
        'LabelMilliseconds
        '
        Me.LabelMilliseconds.AutoSize = True
        Me.LabelMilliseconds.BackColor = System.Drawing.Color.Black
        Me.LabelMilliseconds.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMilliseconds.ForeColor = System.Drawing.Color.White
        Me.LabelMilliseconds.Location = New System.Drawing.Point(495, 60)
        Me.LabelMilliseconds.Name = "LabelMilliseconds"
        Me.LabelMilliseconds.Size = New System.Drawing.Size(34, 26)
        Me.LabelMilliseconds.TabIndex = 27
        Me.LabelMilliseconds.Text = "00"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Black
        Me.Label3.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(482, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(18, 26)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = ":"
        '
        'LabelMet2
        '
        Me.LabelMet2.AutoSize = True
        Me.LabelMet2.BackColor = System.Drawing.Color.Black
        Me.LabelMet2.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMet2.ForeColor = System.Drawing.Color.White
        Me.LabelMet2.Location = New System.Drawing.Point(269, 394)
        Me.LabelMet2.Name = "LabelMet2"
        Me.LabelMet2.Size = New System.Drawing.Size(57, 23)
        Me.LabelMet2.TabIndex = 29
        Me.LabelMet2.Text = "Segon"
        '
        'LabelMet3
        '
        Me.LabelMet3.AutoSize = True
        Me.LabelMet3.BackColor = System.Drawing.Color.Black
        Me.LabelMet3.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMet3.ForeColor = System.Drawing.Color.White
        Me.LabelMet3.Location = New System.Drawing.Point(477, 394)
        Me.LabelMet3.Name = "LabelMet3"
        Me.LabelMet3.Size = New System.Drawing.Size(57, 23)
        Me.LabelMet3.TabIndex = 30
        Me.LabelMet3.Text = "Tercer"
        '
        'LabelMet4
        '
        Me.LabelMet4.AutoSize = True
        Me.LabelMet4.BackColor = System.Drawing.Color.Black
        Me.LabelMet4.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMet4.ForeColor = System.Drawing.Color.White
        Me.LabelMet4.Location = New System.Drawing.Point(676, 394)
        Me.LabelMet4.Name = "LabelMet4"
        Me.LabelMet4.Size = New System.Drawing.Size(55, 23)
        Me.LabelMet4.TabIndex = 31
        Me.LabelMet4.Text = "Quart"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(381, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 26)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Temps:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(898, 442)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LabelMet4)
        Me.Controls.Add(Me.LabelMet3)
        Me.Controls.Add(Me.LabelMet2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.LabelMilliseconds)
        Me.Controls.Add(Me.LabelSeconds)
        Me.Controls.Add(Me.LabelMet1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox18)
        Me.Controls.Add(Me.PictureBox17)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox16)
        Me.Controls.Add(Me.PictureBox15)
        Me.Controls.Add(Me.PictureBox14)
        Me.Controls.Add(Me.PictureBox13)
        Me.Controls.Add(Me.PictureBox12)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ButtonStart)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox19)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Carrera de relleus"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ButtonStart As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents JocToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ImageCorredores As ImageList
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents NouJocToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FinestraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MinimitzaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents ButtonVerd As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ButtonRosa As Button
    Friend WithEvents ButtonGroc As Button
    Friend WithEvents ButtonBlau As Button
    Friend WithEvents LabelMet1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents LabelSeconds As Label
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents LabelMilliseconds As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelMet2 As Label
    Friend WithEvents LabelMet3 As Label
    Friend WithEvents LabelMet4 As Label
    Friend WithEvents SurtirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label2 As Label
End Class
